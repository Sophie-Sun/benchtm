library(testthat)
library(benchtm)

test_check("benchtm")
